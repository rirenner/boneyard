#! /usr/bin/python

from onep.element import NetworkElement
from onep.element import SessionConfig
from onep.interfaces.InterfaceStatistics import InterfaceStatistics
from onep.interfaces.InterfaceStatisticsFilter import InterfaceStatisticsFilter
InterfaceStatisticsParameter = InterfaceStatistics.InterfaceStatisticsParameter


ne = NetworkElement("", "testapp")
config = SessionConfig(None)
config.transportMode = SessionConfig.SessionTransportMode.TIPC
con = ne.connect('admin', 'Cisco321', config)

intf = ne.get_interface_by_name('Ethernet1/1')

addresses = intf.get_address_list()
statistics = intf.get_statistics()
bin = str(statistics.get_param(InterfaceStatisticsParameter.ONEP_IF_STAT_RX_PKTS_BCAST)) 

for address in addresses:
    if address != None:
        outter = "Interface - " + intf.name + " Address: " + address + \
        " Broadcasts in: " + bin
        print outter

ne.create_syslog_message(0, outter)
ne.disconnect()
