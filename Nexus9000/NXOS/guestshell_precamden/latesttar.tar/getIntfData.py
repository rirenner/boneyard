#!/usr/bin/python

import requests
import json

"""
Modify these please
"""
url='http://localhost/ins'
switchuser='admin'
switchpassword='Cisco321'

myheaders={'content-type':'application/json-rpc'}
payload=[
  {
    "jsonrpc": "2.0",
    "method": "cli",
    "params": {
      "cmd": "show int mgmt0",
      "version": 1
    },
    "id": 1
  }
]
response = requests.post(url,data=json.dumps(payload), headers=myheaders,auth=(switchuser,switchpassword)).json()
name = response['result']['body']['TABLE_interface']['ROW_interface']['interface']
pkts_in = response['result']['body']['TABLE_interface']['ROW_interface']['vdc_lvl_in_pkts']
bytes_in = response['result']['body']['TABLE_interface']['ROW_interface']['vdc_lvl_in_bytes']
pkts_out = response['result']['body']['TABLE_interface']['ROW_interface']['vdc_lvl_out_pkts']
bytes_out = response['result']['body']['TABLE_interface']['ROW_interface']['vdc_lvl_out_bytes']


outter = "\n interface: " + name + ",\n packets_in: " + str(pkts_in) + ",\n bytes_in: " + str(bytes_in) + ",\n packets_out: " + str(pkts_out) + ",\n bytes_out: " + str(bytes_out) + ""


print outter + "\n"

