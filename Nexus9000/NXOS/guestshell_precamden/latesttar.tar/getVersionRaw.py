#!/usr/bin/python

import requests
import json

"""
Modify these please
"""
url='http://localhost/ins'
switchuser='admin'
switchpassword='Cisco321'

myheaders={'content-type':'application/json-rpc'}
payload=[
  {
    "jsonrpc": "2.0",
    "method": "cli",
    "params": {
      "cmd": "show version",
      "version": 1
    },
    "id": 1
  }
]
response = requests.post(url,data=json.dumps(payload), headers=myheaders,auth=(switchuser,switchpassword)).json()
#print response
print json.dumps(response, indent=4, sort_keys=True) 
