#!/usr/bin/env python

import sys

print "Hello, World!"
list = ['one', 'two', 'three']
for item in list:
    print item
