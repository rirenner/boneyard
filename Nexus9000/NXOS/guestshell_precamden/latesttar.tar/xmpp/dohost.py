#!/usr/bin/python
import logging
from sleekxmpp import ClientXMPP
from sleekxmpp.exceptions import IqError, IqTimeout
from subprocess import call
import subprocess
import commands


class EchoBot(ClientXMPP):

    def __init__(self, jid, password):
        ClientXMPP.__init__(self, jid, password)
        self.add_event_handler("session_start", self.session_start)
        self.add_event_handler("message", self.message)
        self.add_event_handler("groupchat_invite", self.accept_invite)

    def session_start(self, event):
        self.send_presence()
        self.get_roster()


    def message(self, msg):
        if msg['type'] in ('chat', 'normal'):
            str = "%(body)s" % msg
            sstr = str.split(';')
            sstr.insert(0, "dohost")
            #final = ["dohost", "conf t", "show clock"]
            final = sstr
            p = subprocess.Popen(final, stdout=subprocess.PIPE)
            outj = p.stdout.read()
            #print outj
            msg.reply("Output:\n%s" % outj).send()
    
    def accept_invite(self, inv):
	print("Invite from %s to %s" %(inv["from"], inv["to"]))

if __name__ == '__main__':
    # Ideally use optparse or argparse to get JID,
    # password, and log level.
    logging.basicConfig(level=logging.DEBUG,
                        format='%(levelname)-8s %(message)s')

    xmpp = EchoBot('9396px@localhost', 'test2')
    xmpp.connect(('10.95.33.98', 5222))
    xmpp.process(block=True)

